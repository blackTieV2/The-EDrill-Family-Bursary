# The EDrill Family Bursary - Employee FAQ

Status: Draft for internal review only  
Version: 0.1  
Important: do not issue until eligibility, privacy, payment, and application dates are approved.

## 1. What is The EDrill Family Bursary?

It is a company-funded education support initiative intended to assist eligible families connected with EDrill Thailand operations with approved schooling costs.

## 2. Is the Bursary guaranteed?

No. The Bursary is discretionary, limited, and subject to eligibility, evidence, available places, budget, and annual review.

## 3. Who can apply?

The first award cycle is intended for eligible employees connected with EDrill Thailand operations. If approved, eligible employees of the appointed labour-hire agency at the time of application who are assigned to EDrill rigs may also be considered under separate verification rules.

## 4. Which children are eligible?

The child must meet the approved age, relationship/dependency, schooling, and evidence requirements. An eligible child must be 12 years old or younger throughout the relevant Award Year.

A family may apply for multiple eligible children. Each child/application is means-tested and assessed separately under the approved criteria and the annual award cap.

## 5. Are private schools included?

Government and private schools in Thailand are included, subject to the approved rules and evidence requirements.

## 6. Are international schools included?

Applicants must list the school the child attends. Government and private schools in Thailand are included, and any international-school or high-cost application will be reviewed under the approved rules before awards are confirmed.

## 7. What costs may be covered?

Provisional eligible costs include tuition, compulsory school fees, textbooks, uniforms, and required school materials. The final eligible costs will be confirmed before applications open.

## 8. How much is the Bursary?

The Phase 1 EDrill employee award value is up to THB 120,000 per awardee per Award Year. The labour-hire category, if applicable, is up to THB 8,000 per month, paid quarterly.

## 9. How will payment be made?

For EDrill employees, approved awards are paid into the recipient employee's bank account through the normal payroll session and added as a line item on the employee's payslip. For eligible labour-hire agency employees, EDPL pays the appointed labour-hire agency at the time of application, and the agency pays onward to its employee using its existing payroll/payment process.

## 10. Will the payment be taxable?

Bursary payments are tax liable to the recipient. Recipients are responsible for their own tax position. Payments must not be described as tax-free or non-taxable.

## 11. What documents are required?

The application pack will confirm required documents. The core applicant documents are a birth certificate or approved equivalent evidence, a school enrolment letter or confirmation, and the applicant declaration/consent. Finance will confirm salary eligibility internally.

## 12. Does eligibility guarantee an award?

No. If eligible applications exceed available places, applications will be reviewed and ranked under the approved selection method.

## 13. Is renewal automatic?

No. There is no automatic renewal and no automatic renewal priority. Each award year is a reset. Existing recipients may reapply and will be assessed under the same criteria as other applicants, subject to eligibility, available places, and annual approval.

## 14. Can I appeal?

Appeals may be submitted to the Chairman of the Committee for review. Appeals are limited to procedural error, new material evidence, exceptional hardship, or incorrect eligibility assessment.

## 15. Who should I contact?

Contact Bangkok HR: [name / email / phone]
