> Superseded by approved issue: see `01_drafting/eligibility-criteria/approved/EDrill_Family_Bursary_Eligibility_and_Selection_Rules.md`.

# The EDrill Family Bursary - Eligibility and Selection Rules

Status: Draft for internal review only  
Version: 0.1  
Effective date: 1 October 2026
Owner: Bursary Committee Chairman
Important: this draft reflects confirmed Phase 1 management decisions recorded in the decision log. It remains in draft form and must not be treated as operational until the Launch Approval Checklist records all required Phase 1 approvals and final communications checks.

## 1. Purpose

These Rules define who may apply for The EDrill Family Bursary, which children and schools are eligible, how applications are screened, and how awardees are selected if eligible applications exceed the number of available bursaries.

These Rules support the Bursary Charter and Procedure / SOP.

## 2. Core Principles

The Bursary should be administered according to the following principles:

1. Fairness: similar applications should be treated consistently.
2. Need: the Bursary is intended as family education support, not an academic prize.
3. Evidence: eligibility must be supported by documents or internal verification.
4. Discretion: eligibility does not guarantee an award.
5. Privacy: only necessary personal and family data should be collected.
6. Transparency: selection criteria should be documented before applications are reviewed.
7. Conflict control: reviewers must declare conflicts and recuse themselves where required.

## 3. Award Year

The first Award Year is intended to begin on 1 October 2026.

The final Award Year dates, application opening date, and application closing date must be approved before applications open.

## 4. Eligible Applicant Categories

The eligible applicant categories are:

1. Eligible EDrill employees connected with Thailand operations.
2. Eligible employees of the appointed labour-hire agency at the time of application who are assigned to EDrill rigs, if labour-hire participation is approved.

The Bursary does not apply to Myanmar or other locations unless formally extended.

## 5. EDrill Employee Eligibility

An EDrill employee is eligible to apply if all of the following apply:

1. The employee is connected with Thailand operations or assigned to an approved Thailand operation.
2. The employee is in an approved employee group or rig/office scope, including ED1, ED2, T15, T16, GHTH, and EVE.
3. The employee's monthly salary is below THB 100,000 using the approved salary definition.
4. The employee meets the approved minimum service requirement.
5. The employee has an eligible child enrolled in an eligible school in Thailand.
6. The employee submits the required application and evidence by the deadline.
7. The employee is not receiving a duplicate education benefit for the same child and same expense.

## 6. Salary Threshold

The salary threshold is monthly salary below THB 100,000.

For eligibility purposes, monthly salary means:

> gross fixed monthly salary, excluding variable components, allowances, bonuses, overtime, offshore payments, discretionary payments, and other non-fixed amounts, unless otherwise approved by Finance and the Committee.

The salary threshold should be tested at:

1. application closing date; and
2. award approval date.

Finance verifies salary eligibility internally using this definition.

## 7. Minimum Service

The employee or labour-hire eligible worker must have continuous service or assignment connected with EDrill Thailand operations from 1 January 2025, with no break exceeding 30 days, unless an exception is approved by the Committee.

## 8. Labour-Hire Agency Eligibility

Labour-hire agency participation may be used only where the appointed labour-hire agency participation model and acknowledgement are approved.

If approved, a labour-hire agency employee may be eligible if all of the following apply:

1. The individual is an employee of the appointed labour-hire agency at the time of application, not EDrill.
2. The individual is assigned to EDrill rigs.
3. The individual has continuous assignment connected with EDrill Thailand operations from 1 January 2025, with no break exceeding 30 days, unless an exception is approved by the Committee.
4. The relevant labour-hire agency verifies employment status.
5. EDrill Operations verifies assignment and continuity.
6. Any required labour-hire agency acknowledgement is obtained.
7. The child meets the child and schooling eligibility rules.
8. Required evidence is provided.

All labour-hire wording must avoid implying that labour-hire agency employees are EDrill employees. Use the following wording:

> eligible employees of the appointed labour-hire agency at the time of application who are assigned to EDrill rigs

## 9. Eligible Child

An eligible child must:

1. be 12 years old or younger throughout the relevant Award Year;
2. be the child, adopted child, stepchild, legal dependant, or child under legal guardianship of the applicant, if supported by documents;
3. be enrolled in an eligible school in Thailand;
4. not be receiving duplicate education support for the same expense under another company benefit.

## 10. Multiple Children Per Family

A family may apply for multiple eligible children. Each child/application is means-tested and assessed separately under the approved criteria and the annual award cap.

## 11. Eligible Schools

The eligible school categories are:

- government schools in Thailand;
- private schools in Thailand;
- special education schools in Thailand, if properly evidenced.

Applicants must list the school attended. Government and private schools in Thailand are included. International schools should be reviewed for cost reasonableness unless the Executive Sponsor approves an exclusion, cap, or separate rule.

Homeschooling and online schooling are excluded for the first launch unless legally recognised and evidence is clear.

## 12. Evidence Required

Applicants must provide, or allow HR/Finance/Operations to verify, the evidence required by the application pack.

Evidence requirements include:

- completed application form;
- birth certificate or approved equivalent;
- school enrolment letter or confirmation;
- school invoice, fee note, receipt, or equivalent;
- declaration of other education support;
- applicant declaration and consent;
- labour-hire agency employment and assignment verification, if applicable.

Finance verifies salary eligibility internally. Applicants should not be required to submit a payslip unless Finance later requires it as an exception.

## 13. Ineligibility

An application may be declined if:

- eligibility is not met;
- required evidence is missing;
- documents cannot be verified;
- information is false, misleading, incomplete, or withheld in a material way;
- the child or school is outside approved scope;
- the applicant receives a duplicate education benefit for the same expense;
- the application is late and no exception is approved;
- the applicant refuses required consent or verification;
- there is a conflict, fraud, or compliance concern.

## 14. Selection When Applications Do Not Exceed Available Places

If eligible applications are equal to or fewer than the approved number of Bursary places, the Committee may recommend all eligible applications, subject to:

- budget availability;
- complete evidence;
- Finance approval;
- final approving authority approval.

Eligibility alone does not create an entitlement.

## 15. Selection When Applications Exceed Available Places

If eligible applications exceed available places, the Committee must apply the approved scoring model.

The scoring model is:

| Criterion | Points | Guidance |
| --- | ---: | --- |
| Financial need / salary band below threshold | 0-35 | Lower salary and stronger financial need receive higher score |
| Number of dependent children | 0-15 | More dependants may receive higher score |
| School cost burden | 0-20 | Higher cost burden relative to income may receive higher score |
| Special hardship | 0-15 | Medical, disability, single-parent household, sudden hardship, or other approved hardship |
| Length of service / continuity | 0-10 | Longer verified service or assignment may receive higher score |
| Completeness of evidence | 0-5 | Complete, reliable, timely application |
| Total | 100 | Rank from highest to lowest score |

The Committee must record scoring outcomes and reasons.

## 16. Tie-Breakers

If applicants receive the same score, the tie-breakers are:

1. lower employee salary;
2. more dependent children;
3. higher school cost burden;
4. longer service or verified continuous assignment;
5. Committee Chair decision, recorded with reasons.

## 17. Renewal Selection

There is no automatic renewal and no automatic renewal priority.

Each award year is a reset. Existing recipients may reapply and will be assessed under the same criteria as other applicants, subject to eligibility, available places, and annual approval.

## 18. Appeals

Appeals may be submitted only on approved grounds:

- procedural error;
- new material evidence;
- exceptional hardship;
- incorrect eligibility assessment.

Appeals are not a second opportunity to re-argue a properly applied scoring outcome.

Rejected applicants may appeal to the Chairman of the Committee for review under the approved appeal process.

## 19. Exceptions

Any exception to these Rules must:

- be recorded in writing;
- identify the reason;
- identify the approving authority;
- confirm that Finance/Legal review is not required, or record that it was obtained;
- not undermine the fairness or integrity of the Bursary.

## 20. Approval

| Role | Name | Signature / approval record | Date |
| --- | --- | --- | --- |
| Executive Sponsor |  |  |  |
| HR / Bangkok Administrator |  |  |  |
| Finance |  |  |  |
| Legal / Compliance |  |  |  |
| Operations |  |  |  |
