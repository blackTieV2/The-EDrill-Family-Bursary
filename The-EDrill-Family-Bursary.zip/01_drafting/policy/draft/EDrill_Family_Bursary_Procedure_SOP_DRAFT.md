# The EDrill Family Bursary - Procedure / SOP

Status: Draft for internal review only  
Version: 0.1  
Effective date: 1 October 2026
Owner: Bangkok Office / Bursary Administrator
Administrator: Bangkok Office / Bursary Administrator
Important: this draft reflects confirmed Phase 1 management decisions recorded in the decision log. It remains in draft form and must not be treated as operational until the Launch Approval Checklist records all required Phase 1 approvals and final communications checks.

## 1. Purpose

This Procedure describes how The EDrill Family Bursary is administered from annual planning through application, review, award, payment, renewal, reporting, and annual review.

It supports the Bursary Charter and must be read together with the approved Eligibility and Selection Rules, forms, privacy notices, and payment controls.

## 2. Scope

This Procedure applies to the first implementation of the Bursary for Thailand operations.

The first implementation is intended to cover:

- eligible Energy Drilling employees connected with Thailand operations; and
- subject to approval, eligible employees of the appointed labour-hire agency at the time of application who are assigned to EDrill rigs.

This Procedure does not apply to Myanmar or other locations unless formally extended.

## 3. Key Controls

No award may be issued unless:

1. the funding entity is EDPL and routine Finance processing details are recorded;
2. the annual budget is approved;
3. recipient-taxable treatment is recorded;
4. the approved payroll or labour-hire agency payment route is used;
5. applicant consent, confidentiality, data minimisation, anonymised Committee review where practicable, and restricted access controls are used;
6. the confirmed Phase 1 Committee members have completed conflict-of-interest and confidentiality declarations before review/decision activity;
7. the selection method is approved;
8. labour-hire agency participation is approved, if applicable;
9. the applicant meets eligibility requirements;
10. required evidence is complete.

## 4. Roles and Responsibilities

| Role | Responsibilities |
| --- | --- |
| Executive Sponsor | Approves scheme launch, annual budget, material changes, and final award recommendations where required |
| Bangkok HR / Administrator | Coordinates application cycle, receives applications, checks completeness, maintains records, communicates with applicants |
| Finance / Payroll | Administers the approved payroll route, records cost centre / GL details as administrative processing items, verifies salary-cap eligibility, and supports payment execution |
| Operations | Confirms rig assignment, operational eligibility, and labour-hire agency assignment/continuity where relevant |
| Chairman / Committee internal compliance | Approves Phase 1 consent, confidentiality, data minimisation, discretionary wording, labour-hire agency wording, and communications controls; no external legal advice obtained |
| Bursary Committee | Reviews eligible applications, manages conflicts, applies selection method, records recommendations |
| Labour-Hire Agency Contact, if applicable | Verifies agency employment status, supports onward payment where approved, and provides any required acknowledgement |

## 5. Annual Timetable

First-year timetable:

| Step | Target timing |
| --- | --- |
| Confirm budget and launch gates | Before internal announcement |
| Internal announcement issued | 1 October 2026 |
| Application window opens | 1 October 2026 |
| Application window closes | 31 October 2026 |
| Finance eligibility screen completed by | 15 November 2026 |
| Committee review completed by | 30 November 2026 |
| Award approval | Within 4 weeks of closing date |
| First payment | Next available payroll cycle after award approval |
| Quarterly evidence/payment review | Each quarter |
| Annual review | End of Award Year |

## 6. Annual Planning Process

Before each Award Year, Bangkok HR should prepare an annual planning note covering:

- proposed application window;
- confirmed number of available bursaries;
- confirmed award value;
- confirmed budget;
- routine Finance processing details, including cost centre / GL code if required by Finance;
- confirmed committee members;
- any rule changes from prior year;
- status of payroll, privacy, payment, agency, and communications controls.

The Executive Sponsor or delegated authority must approve the annual planning note before applications open.

## 7. Communication Before Applications Open

HR may issue an internal launch message only after approval.

The launch message should explain:

- the purpose of the Bursary;
- who may apply;
- what support may be available;
- that awards are discretionary and limited;
- that renewal is not automatic;
- application deadline;
- evidence required;
- contact person;
- data/privacy notice.

The launch message must avoid describing the Bursary as a charity, foundation, registered society, public fund, donation-funded programme, or guaranteed entitlement.

No internal or external communication should be published until the final Chairman/Committee/Communications pre-publication check confirms that the wording contains no fundraising language, does not describe the Bursary as a charity, society, foundation, or ROS body, does not claim tax-free or non-taxable treatment, does not imply guaranteed entitlement, and does not identify children/beneficiaries without specific consent.

## 8. Application Submission

Applicants must submit the approved application form and evidence by the stated deadline.

Applications should be submitted to the nominated Bangkok HR contact or secure submission location.

Late applications may be declined unless HR accepts them under an approved exception process.

## 9. Required Application Documents

The required evidence checklist should be approved before applications open.

Provisional required documents:

1. completed application form;
2. employee identity and employment details;
3. child identity document;
4. evidence of relationship or legal dependency;
5. birth certificate or approved equivalent;
6. school enrolment letter or confirmation;
7. school invoice, fee note, receipt, or equivalent evidence;
8. salary or pay-band confirmation handled internally by HR/Finance;
9. declaration of other education support for the same child;
10. applicant declaration and consent form;
11. for labour-hire applicants, labour-hire agency employment, onward-payment, and EDrill rig assignment verification.

Applicants should not be required to submit a payslip unless Finance later requires it as an exception.

HR should not collect unnecessary sensitive information. Hardship information should be collected only where it is part of the approved scoring model and privacy wording allows it.

## 10. Completeness Check

Bangkok HR should check each application for completeness.

If information is missing, HR may request clarification or additional documents by a stated deadline.

Applications should be marked as:

- complete;
- incomplete pending clarification;
- ineligible;
- referred for exception review.

Incomplete applications may be declined if required documents are not provided by the deadline.

## 11. Eligibility Screening

HR, Finance, and Operations should screen applications against approved eligibility rules.

The eligibility checks include:

- employee is within approved Thailand operations scope;
- employee salary is below THB 100,000 using the approved salary definition;
- employee meets any minimum service requirement;
- child meets age requirement;
- child relationship/dependency is evidenced;
- school is in Thailand;
- school attended and school type are recorded for committee/Finance review;
- required evidence is complete;
- no duplicate education benefit applies;
- labour-hire agency employment and continuous assignment requirements are met, if applicable.

For eligibility purposes, monthly salary means gross fixed monthly salary, excluding variable components, allowances, bonuses, overtime, offshore payments, discretionary payments, and other non-fixed amounts, unless otherwise approved by Finance and the Committee.

Finance should complete the salary-cap check before any application is forwarded to the Committee. Committee packs should then be anonymised so far as practical, with Finance/HR retaining the identifiable salary evidence.

Eligibility screening should be documented before committee scoring.

## 12. Labour-Hire Agency Application Handling

Labour-hire agency applications, if approved, should be handled separately in records and reporting.

For each labour-hire applicant:

1. The relevant labour-hire agency should verify employment status.
2. EDrill Operations should verify assignment to EDrill rigs.
3. Continuous service or assignment connected with EDrill Thailand operations from 1 January 2025, with no break exceeding 30 days, should be verified unless an exception is approved by the Committee.
4. HR/Committee should confirm that communications do not describe labour-hire agency staff as EDrill employees.
5. Finance should use the approved payment route to the labour-hire agency and may request confirmation that onward payment was made.

No labour-hire award should be issued until any required agency acknowledgement is obtained.

## 13. Committee Review

The Committee should review only applications that pass eligibility screening, unless an exception review is requested.

Before review begins:

- committee members must declare conflicts of interest;
- conflicted members must recuse themselves from affected applications;
- HR should prepare the review pack;
- applications should be partially anonymised where practical.

The review pack should include:

- application reference number;
- eligibility screening result;
- school cost evidence;
- salary band or approved need indicator, not unnecessary detailed payroll data;
- dependant information, if approved;
- hardship information, if approved;
- prior award status;
- completeness status.

## 14. Selection Method

If eligible applications are equal to or fewer than available bursary places, the Committee may recommend all eligible applicants, subject to budget and approval.

If eligible applications exceed available bursary places, the Committee must apply the approved scoring or ranking method.

Provisional scoring model, to be approved by HR / the Executive Sponsor:

| Criterion | Points |
| --- | ---: |
| Financial need / salary band below threshold | 0-35 |
| Number of dependent children | 0-15 |
| School cost burden | 0-20 |
| Special hardship | 0-15 |
| Length of service / continuity | 0-10 |
| Completeness of evidence | 0-5 |
| Total | 100 |

Recommended tie-breakers:

1. lower employee salary;
2. more dependent children;
3. higher school cost burden;
4. longer service or verified continuous assignment;
5. Committee Chair decision, recorded with reasons.

The final scoring model must be approved before use. No further Marcus clarification is outstanding. If eligible applications exceed available bursary places, the Committee applies a means-tested, need-weighted assessment considering financial need and family circumstances.

## 15. Decision Recording

For each application, the Committee should record:

- application reference number;
- eligibility result;
- score or ranking, if applicable;
- conflicts declared;
- decision or recommendation;
- reasons for decision;
- any conditions;
- required follow-up;
- approval date.

Decision records should be retained according to the approved retention period.

## 16. Award Approval

The Committee approves award decisions.

Award approval should confirm:

- applicant name;
- child name or reference;
- award category;
- approved amount;
- payment route;
- payment schedule;
- conditions;
- tax/payroll handling;
- evidence requirements;
- renewal status.

After Committee approval, Payroll is instructed by the Chairman for EDrill employee awards. No award letter should be issued until the approval record is complete.

## 17. Award Letter and Acceptance

Successful applicants should receive an award letter.

The award letter should state:

- award amount;
- Award Year;
- payment schedule;
- approved expense scope;
- evidence requirements;
- continued eligibility conditions;
- that renewal is not automatic;
- that the Bursary is discretionary;
- that false, misleading, incomplete, or withheld material information may result in disqualification, withdrawal of an award, recovery of amounts paid, and disciplinary or contractual action where applicable;
- privacy and consent references;
- contact point for questions.

The applicant should acknowledge the award conditions before payment is made.

## 18. Unsuccessful Applications

Unsuccessful applicants should receive a short written notification.

The notification should avoid detailed comparison with other applicants and should state, where appropriate, that:

- Bursary places are limited;
- eligibility does not guarantee an award;
- the applicant may apply again in a future cycle if eligible;
- rejected applicants may appeal to the Chairman of the Committee for review under the approved appeal grounds.

## 19. Payment Processing

Finance should process payment only after:

1. award approval is complete;
2. award letter has been accepted;
3. required evidence is complete;
4. payment route is approved;
5. recipient-taxable treatment is recorded;
6. employee bank details or labour-hire agency payment details are verified.

Approved Phase 1 payment route:

1. EDrill employee awards are paid into the recipient employee's bank account through the normal payroll session and added as a line item on the employee's payslip.
2. Labour-hire crew awards are paid by EDPL to the appointed labour-hire agency at the time of application for onward payment to its employee using the agency's existing payroll/payment process.
3. Direct school payment or reimbursement may be used only if approved as an exception or revised process.

Payments should not exceed the approved award value. Evidence of schooling and education-related costs should be retained for audit and control even where the award is paid to an employee bank account or through a labour-hire agency.

## 20. Quarterly Review

Where awards are paid quarterly, HR and Finance should review each recipient before each payment.

The quarterly review should confirm:

- continued employment/assignment eligibility;
- continued school enrolment, where required;
- required receipts or invoices;
- no duplicate benefit;
- no unresolved compliance issue;
- payment amount due.

If employment, assignment, schooling, eligibility, or other relevant circumstances change during an Award Year, the Committee may continue, suspend, cease, or prorate the award on a case-by-case basis, considering the circumstances and the needs of the family.

## 21. Changes in Circumstances

Applicants and recipients must notify HR if:

- employment ends;
- assignment changes;
- salary changes materially, if relevant to eligibility;
- child leaves school;
- school changes;
- another education benefit is received;
- submitted information was incorrect;
- family circumstances relevant to the application change.

The Company may suspend, reduce, stop, prorate, or recover payment where eligibility no longer applies or information was inaccurate, subject to any Committee decision on mid-year eligibility changes.

## 22. Renewal

There is no automatic renewal and no automatic renewal priority. Each award year is a reset.

Before renewal, HR should request updated:

- application or renewal form;
- employment eligibility confirmation;
- salary eligibility confirmation;
- child age and relationship confirmation, if required;
- school enrolment and fee evidence;
- prior payment/evidence record;
- declaration of other support.

Existing recipients may reapply and will be assessed under the same criteria as other applicants, subject to eligibility, available places, and annual approval.

## 23. Appeals and Exceptions

Appeals should be submitted within the approved timeframe.

Permitted grounds:

- procedural error;
- new material evidence;
- exceptional hardship;
- incorrect eligibility assessment.

Rejected applicants may appeal to the Chairman of the Committee for review. Appeals should be reviewed by persons who were not conflicted in the original decision where practical.

Exception approvals must be recorded with reasons and must not undermine the fairness of the scheme.

## 24. Records Management

HR should maintain a secure Bursary evidence file using the Launch Evidence File Register as the control index.

The evidence file should contain:

- approved charter and procedure;
- approved Launch Workplan and RACI;
- completed Launch Approval Checklist;
- decision log;
- Finance / Payroll administration record, if used;
- Chairman/Committee internal compliance approval record;
- labour-hire agency acknowledgement, if applicable;
- application forms;
- evidence checklists;
- declarations and consents;
- committee review sheets;
- conflict declarations;
- award approvals;
- award letters;
- payment records;
- renewal records;
- appeal records;
- annual reports.

Access should be limited to authorised HR, Finance, Operations, Committee, and approving personnel.

Records should be retained for HR, payroll, audit, tax, and administration needs under restricted access. The Committee may set or update the retention period administratively.

Committee members should receive anonymised review packs where practical and should not receive raw salary data or unnecessary child/family documents unless HR and the Committee approve the disclosure.

## 25. Privacy

The approved privacy notice and consent wording must be included in the application pack.

HR must not share applicant or child data beyond authorised personnel unless:

- it is necessary for administration;
- the applicant has consented where required;
- there is another lawful basis;
- the transfer has been approved under the Chairman/Committee internal compliance position.

Beneficiary names, photos, or personal stories must not be used in internal or external communications without specific written consent.

## 26. Annual Reporting

At the end of each Award Year, HR should prepare an annual scheme report including:

- number of applications;
- number of eligible applications;
- number of awards;
- total approved value;
- total paid value;
- number of renewals;
- number of unsuccessful applications;
- appeals and exceptions;
- operational issues;
- recommendations for next year.

The report should be reviewed by HR, Finance, Operations, and the Executive Sponsor.

## 27. Review and Amendment

This Procedure should be reviewed annually or earlier if:

- tax/payroll treatment changes;
- privacy requirements change;
- the scheme expands to other locations;
- employee/member funding is considered;
- public communications or fundraising are proposed;
- operational issues arise in the first award cycle.

Any material amendment should be approved by the appropriate authority and recorded in the decision log.

## 28. Approval

| Role | Name | Signature / approval record | Date |
| --- | --- | --- | --- |
| Executive Sponsor |  |  |  |
| HR / Bangkok Administrator |  |  |  |
| Finance |  |  |  |
| Chairman / Committee internal compliance |  |  |  |
| Operations |  |  |  |
